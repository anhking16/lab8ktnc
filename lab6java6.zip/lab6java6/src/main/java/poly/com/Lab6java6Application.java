package poly.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab6java6Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab6java6Application.class, args);
	}

}
