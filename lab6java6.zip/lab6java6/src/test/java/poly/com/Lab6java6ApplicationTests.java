package poly.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab6java6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
