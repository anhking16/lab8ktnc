package poly.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab2java6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
